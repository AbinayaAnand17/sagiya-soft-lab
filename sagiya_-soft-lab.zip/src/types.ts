export enum SkillCategory {
  LINGUISTIC = "Linguistic",
  DELIVERY = "Delivery",
  COGNITIVE = "Cognitive",
  PROFESSIONAL = "Professional",
}

export interface Skill {
  id: string;
  name: string;
  category: SkillCategory;
  description: string;
}

export interface UserSkillScore {
  skillId: string;
  score: number; // 1.0 - 10.0
  recordedAt: string;
}

export interface Mission {
  id: string;
  title: string;
  description: string;
  estimatedMinutes: number;
  category: string;
  xp: number;
  status: "pending" | "completed";
}

export interface UserProfile {
  id: string;
  fullName: string;
  phoneNumber: string;
  email?: string;
  role?: 'user' | 'admin';
  selectedGoals: string[];
  isOnboardingComplete: boolean;
  streakCount: number;
  totalXP: number;
  level: number;
  lastActive: string;
}

export const SKILLS: Skill[] = [
  // Linguistic
  { id: "grammar", name: "Grammar", category: SkillCategory.LINGUISTIC, description: "Correctness of syntax and sentence structure." },
  { id: "vocabulary", name: "Vocabulary", category: SkillCategory.LINGUISTIC, description: "Richness and appropriateness of word choice." },
  { id: "clarity", name: "Clarity", category: SkillCategory.LINGUISTIC, description: "How easy it is to understand the message." },
  // Delivery
  { id: "fluency", name: "Fluency", category: SkillCategory.DELIVERY, description: "Smoothness of speech and words per minute." },
  { id: "confidence", name: "Confidence", category: SkillCategory.DELIVERY, description: "Self-assurance and lack of hesitation." },
  { id: "pacing", name: "Pacing", category: SkillCategory.DELIVERY, description: "Speed and rhythm of delivery." },
  // Cognitive
  { id: "logic", name: "Logic", category: SkillCategory.COGNITIVE, description: "Structured flow and reasoning in answers." },
  { id: "adaptability", name: "Adaptability", category: SkillCategory.COGNITIVE, description: "Handling curveball questions and changing context." },
  { id: "eq", name: "EQ", category: SkillCategory.COGNITIVE, description: "Emotional intelligence and tone calibration." },
  // Professional
  { id: "tone", name: "Tone", category: SkillCategory.PROFESSIONAL, description: "Appropriateness of tone for the setting." },
  { id: "professionalism", name: "Professionalism", category: SkillCategory.PROFESSIONAL, description: "Adherence to workplace etiquette." },
  { id: "formality", name: "Formality", category: SkillCategory.PROFESSIONAL, description: "Level of formal language used." },
  // Additional to reach 15
  { id: "empathy", name: "Empathy", category: SkillCategory.COGNITIVE, description: "Understanding and sharing feelings of others." },
  { id: "persuasion", name: "Persuasion", category: SkillCategory.PROFESSIONAL, description: "Ability to influence others' beliefs or actions." },
  { id: "active_listening", name: "Active Listening", category: SkillCategory.DELIVERY, description: "Fully concentrating and responding to the speaker." },
];

export interface PracticeSession {
  id: string;
  userId: string;
  sessionType: string;
  transcript: string;
  messages: {
    role: 'user' | 'ai';
    text: string;
    timestamp: string;
    audioUrl?: string;
    feedback?: string;
  }[];
  aiFeedbackSummary: string;
  durationSeconds: number;
  purgedAt?: string;
  createdAt: string;
}

export const GOALS = [
  "Placement Ready",
  "Public Speaking",
  "Professional Writing",
  "Leadership",
  "Confidence",
  "Comprehensive Professional Growth"
];
