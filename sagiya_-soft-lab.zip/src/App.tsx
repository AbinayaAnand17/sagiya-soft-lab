import React, { createContext, useContext, useEffect, useState } from 'react';
import { 
  BrowserRouter as Router, 
  Routes, 
  Route, 
  Navigate, 
  useLocation 
} from 'react-router-dom';
import { onAuthStateChanged, User } from 'firebase/auth';
import { doc, onSnapshot } from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType } from './firebase';
import { UserProfile } from './types';

// Components
import Login from './components/Login';
import Register from './components/Register';
import Onboarding from './components/Onboarding';
import Dashboard from './components/Dashboard';
import MentorChat from './components/MentorChat';
import Analytics from './components/Analytics';
import Settings from './components/Settings';
import SessionReplay from './components/SessionReplay';

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType>({ user: null, profile: null, loading: true });

export const useAuth = () => useContext(AuthContext);

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      if (!currentUser) {
        setProfile(null);
        setLoading(false);
      }
    });

    return () => unsubscribeAuth();
  }, []);

  useEffect(() => {
    if (!user) return;

    const profileRef = doc(db, 'users', user.uid);
    const unsubscribeProfile = onSnapshot(profileRef, (docSnap) => {
      if (docSnap.exists()) {
        setProfile(docSnap.data() as UserProfile);
      } else {
        setProfile(null);
      }
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `users/${user.uid}`);
      setLoading(false);
    });

    return () => unsubscribeProfile();
  }, [user]);

  if (loading) {
    return (
      <div className="min-h-screen bg-brand-charcoal flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-brand-orange border-t-transparent rounded-full animate-spin"></div>
          <h1 className="text-brand-orange font-bold text-2xl animate-pulse">SAGIYA: SOFT LAB</h1>
        </div>
      </div>
    );
  }

  return (
    <AuthContext.Provider value={{ user, profile, loading }}>
      <Router>
        <Routes>
          <Route path="/login" element={!user ? <Login /> : <Navigate to="/" />} />
          <Route path="/register" element={!user ? <Register /> : <Navigate to="/" />} />
          <Route 
            path="/onboarding" 
            element={user ? (profile?.isOnboardingComplete ? <Navigate to="/" /> : <Onboarding />) : <Navigate to="/login" />} 
          />
          <Route 
            path="/" 
            element={
              user ? (
                profile?.isOnboardingComplete ? <Dashboard /> : <Navigate to="/onboarding" />
              ) : <Navigate to="/login" />
            } 
          />
          <Route path="/mentor" element={user && profile?.isOnboardingComplete ? <MentorChat /> : <Navigate to="/login" />} />
          <Route path="/analytics" element={user && profile?.isOnboardingComplete ? <Analytics /> : <Navigate to="/login" />} />
          <Route path="/replay/:sessionId" element={user && profile?.isOnboardingComplete ? <SessionReplay /> : <Navigate to="/login" />} />
          <Route path="/settings" element={user && profile?.isOnboardingComplete ? <Settings /> : <Navigate to="/login" />} />
        </Routes>
      </Router>
    </AuthContext.Provider>
  );
}
