import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Mic, 
  Send, 
  ChevronLeft, 
  MoreVertical, 
  Sparkles,
  Volume2,
  VolumeX,
  X,
  CheckCircle2,
  BarChart3
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { GoogleGenAI } from "@google/genai";
import { useAuth } from '../App';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { collection, addDoc, serverTimestamp, doc, setDoc } from 'firebase/firestore';
import { SKILLS } from '../types';
import { cn } from '../lib/utils';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

interface Message {
  id: string;
  role: 'user' | 'ai';
  text: string;
  timestamp: Date;
  feedback?: string; // Real-time feedback
}

export default function MentorChat() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [messages, setMessages] = useState<Message[]>([
    { id: '1', role: 'ai', text: "Hello! I'm your Sagiya Mentor. Ready to practice your communication skills today?", timestamp: new Date() }
  ]);
  const [input, setInput] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isThinking, setIsThinking] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [showSummary, setShowSummary] = useState(false);
  const [sessionStats, setSessionStats] = useState<any>(null);
  const [activeFeedback, setActiveFeedback] = useState<string | null>(null);
  const [timer, setTimer] = useState(0);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let interval: any;
    if (!showSummary) {
      interval = setInterval(() => {
        setTimer(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [showSummary]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isThinking]);

  const getRealTimeFeedback = async (text: string) => {
    try {
      const result = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Analyze this student's response for soft skill errors (fillers, tone, clarity). 
        Response: "${text}"
        If there's an immediate improvement tip, provide it in 10 words or less. Otherwise return "OK".`,
        config: { temperature: 0.1 }
      });
      const tip = result.text?.trim();
      if (tip && tip !== "OK") {
        setActiveFeedback(tip);
        // Clear feedback after 5 seconds
        setTimeout(() => setActiveFeedback(null), 5000);
        return tip;
      }
    } catch (err) {
      console.error("Feedback error:", err);
    }
    return undefined;
  };

  const handleSend = async (text: string) => {
    if (!text.trim()) return;

    const userMsg: Message = { id: Date.now().toString(), role: 'user', text, timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsThinking(true);

    // Get real-time feedback in parallel
    getRealTimeFeedback(text).then(feedback => {
      if (feedback) {
        setMessages(prev => prev.map(m => m.id === userMsg.id ? { ...m, feedback } : m));
      }
    });

    try {
      const history = messages.map(m => `${m.role === 'user' ? 'Student' : 'Mentor'}: ${m.text}`).join('\n');
      const prompt = `
        You are the Sagiya: Soft Lab AI Mentor. 
        Context: The user is a student working on soft skills. Their goals are: ${profile?.selectedGoals.join(', ')}.
        Current Conversation History:
        ${history}
        
        Student's latest input: "${text}"
        
        Respond as a professional, encouraging mentor. Keep your response concise (under 3 sentences).
      `;

      const result = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          systemInstruction: "You are a world-class soft skills coach. Your tone is professional, high-energy, and encouraging.",
          temperature: 0.7,
        }
      });

      const aiText = result.text || "I'm sorry, I couldn't process that. Let's try again.";
      const aiMsg: Message = { id: (Date.now() + 1).toString(), role: 'ai', text: aiText, timestamp: new Date() };
      setMessages(prev => [...prev, aiMsg]);
    } catch (err) {
      console.error(err);
    } finally {
      setIsThinking(false);
    }
  };

  const toggleRecording = () => {
    if (isRecording) {
      setIsRecording(false);
      // Simulate STT
      handleSend("I'm feeling a bit nervous about my upcoming placement interview. How can I improve my confidence?");
    } else {
      setIsRecording(true);
    }
  };

  const endSession = async () => {
    setIsThinking(true);
    try {
      const transcript = messages.map(m => `${m.role}: ${m.text}`).join('\n');
      
      const evaluationPrompt = `
        Analyze this conversation transcript between a soft-skills mentor and a student.
        Rate the student from 1.0 to 10.0 on these 4 metrics: verbal_clarity, confidence, logic, professionalism.
        Also provide a 2-sentence summary of their performance and one specific tip.
        
        Transcript:
        ${transcript}
        
        Return ONLY a JSON object:
        {
          "scores": { "verbal_clarity": 7.5, "confidence": 6.0, "logic": 8.0, "professionalism": 7.0 },
          "summary": "...",
          "tip": "..."
        }
      `;

      const evalResult = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: evaluationPrompt,
        config: { responseMimeType: "application/json" }
      });

      const data = JSON.parse(evalResult.text || "{}");
      setSessionStats(data);

      // Save to Firestore
      if (user) {
        const sessionData = {
          id: Date.now().toString(),
          userId: user.uid,
          sessionType: 'Practice',
          transcript,
          messages: messages.map(m => ({
            role: m.role,
            text: m.text,
            timestamp: m.timestamp.toISOString(),
            feedback: m.feedback
          })),
          aiFeedbackSummary: data.summary,
          durationSeconds: Math.floor((Date.now() - messages[0].timestamp.getTime()) / 1000),
          createdAt: serverTimestamp()
        };

        const sessionRef = await addDoc(collection(db, `users/${user.uid}/sessions`), sessionData);

        // Save scores
        const scoreEntries = Object.entries(data.scores);
        for (const [skillId, score] of scoreEntries) {
          await addDoc(collection(db, `users/${user.uid}/skill_scores`), {
            userId: user.uid,
            skillId,
            score,
            sessionId: sessionRef.id,
            recordedAt: serverTimestamp()
          });
        }
      }

      setShowSummary(true);
    } catch (err) {
      console.error(err);
    } finally {
      setIsThinking(false);
    }
  };

  return (
    <div className="min-h-screen bg-brand-pearl flex flex-col">
      {/* Header */}
      <header className="bg-brand-charcoal text-white p-6 flex justify-between items-center shadow-lg z-10">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate('/')} className="p-2 hover:bg-white/10 rounded-xl transition-colors">
            <ChevronLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="font-bold text-lg">AI Mentor</h1>
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-2 bg-brand-success rounded-full animate-pulse"></div>
              <span className="text-[10px] font-bold uppercase tracking-widest text-brand-silver">Live Session • {formatTime(timer)}</span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setIsMuted(!isMuted)} className="p-2 hover:bg-white/10 rounded-xl transition-colors">
            {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
          </button>
          <button onClick={endSession} className="bg-brand-orange px-4 py-2 rounded-xl text-xs font-bold hover:bg-opacity-90 transition-all">
            End Session
          </button>
        </div>
      </header>

      {/* Real-time Feedback Toast */}
      <AnimatePresence>
        {activeFeedback && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-24 left-1/2 -translate-x-1/2 z-20 bg-brand-orange text-white px-6 py-3 rounded-2xl shadow-xl flex items-center gap-3 border border-white/20"
          >
            <Sparkles className="w-5 h-5" />
            <p className="text-sm font-bold">{activeFeedback}</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Chat Area */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-6 space-y-6 scroll-smooth"
      >
        <AnimatePresence initial={false}>
          {messages.map((m) => (
            <motion.div
              key={m.id}
              initial={{ opacity: 0, y: 10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              className={cn(
                "flex flex-col max-w-[85%]",
                m.role === 'user' ? "ml-auto items-end" : "items-start"
              )}
            >
              <div className={cn(
                "p-4 rounded-2xl text-sm font-medium shadow-sm relative",
                m.role === 'user' 
                  ? "bg-brand-orange text-white rounded-tr-none" 
                  : "bg-white text-brand-charcoal border border-brand-silver rounded-tl-none"
              )}>
                {m.text}
                {m.feedback && (
                  <div className="mt-2 pt-2 border-t border-white/20 text-[10px] font-bold flex items-center gap-1 opacity-80">
                    <Sparkles className="w-3 h-3" />
                    Tip: {m.feedback}
                  </div>
                )}
              </div>
              <span className="text-[10px] text-gray-400 mt-1 px-1">
                {m.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </motion.div>
          ))}
          {isThinking && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex items-center gap-2 text-brand-orange"
            >
              <div className="flex gap-1">
                <div className="w-1.5 h-1.5 bg-brand-orange rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                <div className="w-1.5 h-1.5 bg-brand-orange rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                <div className="w-1.5 h-1.5 bg-brand-orange rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
              </div>
              <span className="text-[10px] font-bold uppercase tracking-widest">Mentor is thinking</span>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Input Area */}
      <div className="p-6 bg-white border-t border-brand-silver">
        <div className="max-w-4xl mx-auto flex items-center gap-4">
          <div className="relative flex-1">
            <input 
              type="text" 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend(input)}
              placeholder="Type your message..."
              className="w-full bg-brand-pearl border border-brand-silver rounded-2xl px-6 py-4 text-sm focus:outline-none focus:border-brand-orange transition-colors"
            />
            <button 
              onClick={() => handleSend(input)}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-2 text-brand-orange hover:bg-orange-50 rounded-xl transition-colors"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
          
          <div className="relative">
            {isRecording && (
              <motion.div 
                animate={{ scale: [1, 1.4, 1], opacity: [0.5, 0, 0.5] }}
                transition={{ repeat: Infinity, duration: 2 }}
                className="absolute inset-0 bg-brand-orange rounded-full"
              />
            )}
            <button 
              onClick={toggleRecording}
              className={cn(
                "relative w-14 h-14 rounded-full flex items-center justify-center shadow-lg transition-all",
                isRecording ? "bg-brand-orange text-white" : "bg-brand-charcoal text-white hover:bg-black"
              )}
            >
              <Mic className={cn("w-6 h-6", isRecording && "animate-pulse")} />
            </button>
          </div>
        </div>
      </div>

      {/* Summary Modal */}
      <AnimatePresence>
        {showSummary && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-brand-charcoal/80 backdrop-blur-sm z-[100] flex items-center justify-center p-6"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="bg-white rounded-[2.5rem] w-full max-w-md overflow-hidden shadow-2xl"
            >
              <div className="bg-brand-orange p-8 text-white text-center relative">
                <button 
                  onClick={() => navigate('/')}
                  className="absolute top-6 right-6 p-2 hover:bg-white/20 rounded-full transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
                <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <BarChart3 className="w-8 h-8" />
                </div>
                <h2 className="text-2xl font-bold">Session Summary</h2>
                <p className="text-white/80 text-sm">Great progress today!</p>
              </div>

              <div className="p-8 space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  {Object.entries(sessionStats?.scores || {}).map(([key, val]: any) => (
                    <div key={key} className="bg-brand-pearl p-4 rounded-2xl border border-brand-silver">
                      <p className="text-[10px] font-bold text-gray-400 uppercase mb-1">{key.replace('_', ' ')}</p>
                      <div className="flex items-end gap-1">
                        <span className="text-xl font-black text-brand-charcoal">{val}</span>
                        <span className="text-[10px] text-gray-400 mb-1">/10</span>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="space-y-2">
                  <h3 className="font-bold text-brand-charcoal flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-brand-orange" />
                    Mentor's Note
                  </h3>
                  <p className="text-sm text-gray-600 leading-relaxed italic">
                    "{sessionStats?.summary}"
                  </p>
                </div>

                <div className="bg-orange-50 p-4 rounded-2xl border border-brand-orange/20">
                  <p className="text-xs font-bold text-brand-orange uppercase mb-1">Pro Tip</p>
                  <p className="text-sm text-brand-charcoal font-medium">
                    {sessionStats?.tip}
                  </p>
                </div>

                <button 
                  onClick={() => navigate('/')}
                  className="w-full bg-brand-charcoal text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-black transition-all"
                >
                  Back to Dashboard
                  <CheckCircle2 className="w-5 h-5" />
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
