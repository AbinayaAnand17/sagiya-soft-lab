import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  CheckCircle2, 
  Mic, 
  Clock, 
  Target, 
  ChevronRight, 
  ChevronLeft,
  Sparkles,
  Volume2
} from 'lucide-react';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType } from '../firebase';
import { GOALS, SKILLS } from '../types';
import { cn } from '../lib/utils';

export default function Onboarding() {
  const [step, setStep] = useState(1);
  const [selectedGoals, setSelectedGoals] = useState<string[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingComplete, setRecordingComplete] = useState(false);
  const [commitment, setCommitment] = useState(30);
  const [loading, setLoading] = useState(false);

  const handleGoalToggle = (goal: string) => {
    if (goal === "Comprehensive Professional Growth") {
      setSelectedGoals(["Comprehensive Professional Growth"]);
      return;
    }
    
    let newGoals = [...selectedGoals].filter(g => g !== "Comprehensive Professional Growth");
    if (newGoals.includes(goal)) {
      newGoals = newGoals.filter(g => g !== goal);
    } else if (newGoals.length < 2) {
      newGoals.push(goal);
    }
    setSelectedGoals(newGoals);
  };

  const startRecording = () => {
    setIsRecording(true);
    // Simulate recording for 5 seconds for demo purposes
    setTimeout(() => {
      setIsRecording(false);
      setRecordingComplete(true);
    }, 5000);
  };

  const handleComplete = async () => {
    if (!auth.currentUser) return;
    setLoading(true);
    try {
      const userRef = doc(db, 'users', auth.currentUser.uid);
      await setDoc(userRef, {
        id: auth.currentUser.uid,
        fullName: auth.currentUser.displayName || "Professional",
        phoneNumber: auth.currentUser.phoneNumber || "N/A",
        email: auth.currentUser.email,
        role: auth.currentUser.email === "sriabi1727@gmail.com" ? "admin" : "user",
        selectedGoals,
        isOnboardingComplete: true,
        streakCount: 1,
        totalXP: 100,
        level: 1,
        lastActive: serverTimestamp(),
        createdAt: serverTimestamp()
      });

      // Initialize baseline scores
      for (const skill of SKILLS) {
        const scoreRef = doc(db, `users/${auth.currentUser.uid}/skill_scores`, `${skill.id}_baseline`);
        await setDoc(scoreRef, {
          userId: auth.currentUser.uid,
          skillId: skill.id,
          score: Math.random() * 3 + 2, // Random baseline between 2 and 5
          recordedAt: serverTimestamp()
        });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `users/${auth.currentUser.uid}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-brand-pearl flex flex-col items-center justify-center p-4">
      <div className="max-w-2xl w-full bg-white rounded-[2.5rem] shadow-2xl overflow-hidden border border-brand-silver">
        {/* Progress Bar */}
        <div className="h-2 bg-brand-silver/30 flex">
          {[1, 2, 3].map((s) => (
            <div 
              key={s} 
              className={cn(
                "flex-1 transition-all duration-500",
                step >= s ? "bg-brand-orange" : "bg-transparent"
              )}
            />
          ))}
        </div>

        <div className="p-8 md:p-12">
          <AnimatePresence mode="wait">
            {step === 1 && (
              <motion.div
                key="step1"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                <div className="text-center space-y-2">
                  <div className="inline-flex items-center justify-center w-12 h-12 bg-orange-100 rounded-2xl mb-2">
                    <Target className="text-brand-orange w-6 h-6" />
                  </div>
                  <h2 className="text-3xl font-bold text-brand-charcoal">Define Your Path</h2>
                  <p className="text-gray-500">Select up to 2 goals to personalize your AI training.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {GOALS.map((goal) => (
                    <button
                      key={goal}
                      onClick={() => handleGoalToggle(goal)}
                      className={cn(
                        "p-6 rounded-2xl border-2 text-left transition-all group",
                        selectedGoals.includes(goal)
                          ? "border-brand-orange bg-orange-50/50"
                          : "border-brand-silver hover:border-brand-orange/50"
                      )}
                    >
                      <div className="flex justify-between items-start mb-2">
                        <div className={cn(
                          "w-10 h-10 rounded-xl flex items-center justify-center transition-colors",
                          selectedGoals.includes(goal) ? "bg-brand-orange text-white" : "bg-brand-silver/30 text-brand-charcoal"
                        )}>
                          <Sparkles className="w-5 h-5" />
                        </div>
                        {selectedGoals.includes(goal) && (
                          <CheckCircle2 className="text-brand-orange w-6 h-6" />
                        )}
                      </div>
                      <h3 className="font-bold text-brand-charcoal group-hover:text-brand-orange transition-colors">
                        {goal}
                      </h3>
                    </button>
                  ))}
                </div>

                <button
                  disabled={selectedGoals.length === 0}
                  onClick={() => setStep(2)}
                  className="w-full bg-brand-charcoal text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-black transition-all"
                >
                  Next Step
                  <ChevronRight className="w-5 h-5" />
                </button>
              </motion.div>
            )}

            {step === 2 && (
              <motion.div
                key="step2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                <div className="text-center space-y-2">
                  <div className="inline-flex items-center justify-center w-12 h-12 bg-orange-100 rounded-2xl mb-2">
                    <Volume2 className="text-brand-orange w-6 h-6" />
                  </div>
                  <h2 className="text-3xl font-bold text-brand-charcoal">Quick Talk</h2>
                  <p className="text-gray-500">Let's capture your baseline. Tell me: What is your biggest professional dream?</p>
                </div>

                <div className="flex flex-col items-center justify-center py-12">
                  <div className="relative">
                    {isRecording && (
                      <motion.div 
                        animate={{ scale: [1, 1.5, 1], opacity: [0.5, 0, 0.5] }}
                        transition={{ repeat: Infinity, duration: 2 }}
                        className="absolute inset-0 bg-brand-orange rounded-full"
                      />
                    )}
                    <button
                      onClick={startRecording}
                      disabled={recordingComplete || isRecording}
                      className={cn(
                        "relative w-32 h-32 rounded-full flex items-center justify-center transition-all shadow-xl",
                        isRecording ? "bg-brand-orange text-white" : "bg-brand-charcoal text-white hover:bg-black",
                        recordingComplete && "bg-brand-success"
                      )}
                    >
                      {recordingComplete ? (
                        <CheckCircle2 className="w-12 h-12" />
                      ) : (
                        <Mic className={cn("w-12 h-12", isRecording && "animate-pulse")} />
                      )}
                    </button>
                  </div>
                  <p className="mt-6 font-medium text-brand-charcoal">
                    {isRecording ? "Listening..." : recordingComplete ? "Baseline Captured!" : "Tap to start (30s)"}
                  </p>
                </div>

                <div className="flex gap-4">
                  <button
                    onClick={() => setStep(1)}
                    className="flex-1 border-2 border-brand-silver text-brand-charcoal py-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-brand-pearl transition-all"
                  >
                    <ChevronLeft className="w-5 h-5" />
                    Back
                  </button>
                  <button
                    disabled={!recordingComplete}
                    onClick={() => setStep(3)}
                    className="flex-[2] bg-brand-charcoal text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 disabled:opacity-50 hover:bg-black transition-all"
                  >
                    Next Step
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </div>
              </motion.div>
            )}

            {step === 3 && (
              <motion.div
                key="step3"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                <div className="text-center space-y-2">
                  <div className="inline-flex items-center justify-center w-12 h-12 bg-orange-100 rounded-2xl mb-2">
                    <Clock className="text-brand-orange w-6 h-6" />
                  </div>
                  <h2 className="text-3xl font-bold text-brand-charcoal">Commitment</h2>
                  <p className="text-gray-500">How much time can you dedicate daily?</p>
                </div>

                <div className="space-y-4">
                  {[15, 30, 45].map((mins) => (
                    <button
                      key={mins}
                      onClick={() => setCommitment(mins)}
                      className={cn(
                        "w-full p-6 rounded-2xl border-2 flex items-center justify-between transition-all",
                        commitment === mins
                          ? "border-brand-orange bg-orange-50/50"
                          : "border-brand-silver hover:border-brand-orange/50"
                      )}
                    >
                      <div className="flex items-center gap-4">
                        <div className={cn(
                          "w-12 h-12 rounded-xl flex items-center justify-center",
                          commitment === mins ? "bg-brand-orange text-white" : "bg-brand-silver/30 text-brand-charcoal"
                        )}>
                          <Clock className="w-6 h-6" />
                        </div>
                        <div className="text-left">
                          <h3 className="font-bold text-brand-charcoal">
                            {mins} Minutes
                          </h3>
                          <p className="text-xs text-gray-500">
                            {mins === 15 ? "Quick Session" : mins === 30 ? "Standard Training" : "Intensive Growth"}
                          </p>
                        </div>
                      </div>
                      {commitment === mins && <CheckCircle2 className="text-brand-orange w-6 h-6" />}
                    </button>
                  ))}
                </div>

                <div className="flex gap-4">
                  <button
                    onClick={() => setStep(2)}
                    className="flex-1 border-2 border-brand-silver text-brand-charcoal py-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-brand-pearl transition-all"
                  >
                    <ChevronLeft className="w-5 h-5" />
                    Back
                  </button>
                  <button
                    disabled={loading}
                    onClick={handleComplete}
                    className="flex-[2] bg-brand-orange text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-opacity-90 transition-all shadow-lg shadow-brand-orange/20"
                  >
                    {loading ? (
                      <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    ) : (
                      <>
                        Start My Transformation
                        <Sparkles className="w-5 h-5" />
                      </>
                    )}
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
