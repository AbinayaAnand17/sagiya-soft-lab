import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ChevronLeft, 
  Play, 
  Pause, 
  RotateCcw, 
  MessageSquare, 
  Sparkles,
  Clock,
  Calendar,
  BarChart3
} from 'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';
import { doc, getDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { useAuth } from '../App';
import { PracticeSession } from '../types';
import { cn } from '../lib/utils';
import { GoogleGenAI, Modality } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export default function SessionReplay() {
  const { sessionId } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [session, setSession] = useState<PracticeSession | null>(null);
  const [loading, setLoading] = useState(true);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentMessageIndex, setCurrentMessageIndex] = useState(-1);
  const [isSpeaking, setIsSpeaking] = useState(false);

  useEffect(() => {
    if (!user || !sessionId) return;

    const fetchSession = async () => {
      try {
        const docRef = doc(db, `users/${user.uid}/sessions`, sessionId);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          setSession(docSnap.data() as PracticeSession);
        }
      } catch (err) {
        handleFirestoreError(err, OperationType.GET, `users/${user.uid}/sessions/${sessionId}`);
      } finally {
        setLoading(false);
      }
    };

    fetchSession();
  }, [user, sessionId]);

  const speakText = async (text: string) => {
    if (isSpeaking) return;
    setIsSpeaking(true);
    try {
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: `Say clearly: ${text}` }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: 'Kore' },
            },
          },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) {
        const audio = new Audio(`data:audio/wav;base64,${base64Audio}`);
        audio.onended = () => setIsSpeaking(false);
        await audio.play();
      } else {
        setIsSpeaking(false);
      }
    } catch (err) {
      console.error("TTS error:", err);
      setIsSpeaking(false);
    }
  };

  const startReplay = () => {
    setIsPlaying(true);
    setCurrentMessageIndex(0);
  };

  useEffect(() => {
    if (isPlaying && session && currentMessageIndex < session.messages.length) {
      const msg = session.messages[currentMessageIndex];
      
      // If it's AI, speak it
      if (msg.role === 'ai') {
        speakText(msg.text);
      }

      const timer = setTimeout(() => {
        if (currentMessageIndex < session.messages.length - 1) {
          setCurrentMessageIndex(prev => prev + 1);
        } else {
          setIsPlaying(false);
        }
      }, msg.text.length * 50 + 2000); // Dynamic delay based on text length

      return () => clearTimeout(timer);
    }
  }, [isPlaying, currentMessageIndex, session]);

  if (loading) {
    return (
      <div className="min-h-screen bg-brand-pearl flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-brand-orange border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!session) {
    return (
      <div className="min-h-screen bg-brand-pearl flex flex-col items-center justify-center p-6 text-center">
        <h2 className="text-2xl font-bold text-brand-charcoal mb-4">Session Not Found</h2>
        <button onClick={() => navigate('/')} className="text-brand-orange font-bold">Back to Dashboard</button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-brand-pearl pb-24">
      <header className="bg-brand-charcoal text-white p-6 flex items-center justify-between sticky top-0 z-10 shadow-md">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate('/analytics')} className="p-2 hover:bg-white/10 rounded-xl transition-colors">
            <ChevronLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="font-bold text-lg">Session Replay</h1>
            <p className="text-[10px] font-bold uppercase tracking-widest text-brand-silver">
              {new Date(session.createdAt).toLocaleDateString()}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => {
              setIsPlaying(!isPlaying);
              if (!isPlaying && currentMessageIndex === -1) setCurrentMessageIndex(0);
            }}
            className="p-3 bg-brand-orange rounded-2xl hover:bg-opacity-90 transition-all shadow-lg shadow-brand-orange/20"
          >
            {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}
          </button>
          <button 
            onClick={() => {
              setIsPlaying(false);
              setCurrentMessageIndex(-1);
            }}
            className="p-3 bg-white/10 rounded-2xl hover:bg-white/20 transition-all"
          >
            <RotateCcw className="w-6 h-6" />
          </button>
        </div>
      </header>

      <main className="p-6 space-y-8 max-w-4xl mx-auto">
        {/* Session Info */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white p-6 rounded-3xl border border-brand-silver shadow-sm">
            <Clock className="text-brand-orange w-5 h-5 mb-2" />
            <p className="text-[10px] font-bold text-gray-400 uppercase">Duration</p>
            <h3 className="text-xl font-black text-brand-charcoal">{Math.floor(session.durationSeconds / 60)}m {session.durationSeconds % 60}s</h3>
          </div>
          <div className="bg-white p-6 rounded-3xl border border-brand-silver shadow-sm">
            <BarChart3 className="text-brand-orange w-5 h-5 mb-2" />
            <p className="text-[10px] font-bold text-gray-400 uppercase">Type</p>
            <h3 className="text-xl font-black text-brand-charcoal">{session.sessionType}</h3>
          </div>
        </div>

        {/* Transcript Replay */}
        <div className="space-y-6">
          <h2 className="text-xl font-bold text-brand-charcoal flex items-center gap-2 px-2">
            <MessageSquare className="w-5 h-5 text-brand-orange" />
            Transcript
          </h2>
          
          <div className="space-y-6">
            {session.messages.map((m, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0.3 }}
                animate={{ 
                  opacity: currentMessageIndex >= idx || !isPlaying ? 1 : 0.3,
                  scale: currentMessageIndex === idx ? 1.02 : 1
                }}
                className={cn(
                  "flex flex-col max-w-[85%]",
                  m.role === 'user' ? "ml-auto items-end" : "items-start"
                )}
              >
                <div className={cn(
                  "p-4 rounded-2xl text-sm font-medium shadow-sm relative transition-all",
                  m.role === 'user' 
                    ? "bg-brand-orange text-white rounded-tr-none" 
                    : "bg-white text-brand-charcoal border border-brand-silver rounded-tl-none",
                  currentMessageIndex === idx && "ring-2 ring-brand-orange ring-offset-2"
                )}>
                  {m.text}
                  {m.feedback && (
                    <div className="mt-2 pt-2 border-t border-white/20 text-[10px] font-bold flex items-center gap-1 opacity-80">
                      <Sparkles className="w-3 h-3" />
                      Tip: {m.feedback}
                    </div>
                  )}
                </div>
                <span className="text-[10px] text-gray-400 mt-1 px-1">
                  {new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </motion.div>
            ))}
          </div>
        </div>

        {/* AI Summary */}
        <section className="bg-brand-charcoal text-white p-8 rounded-[2.5rem] shadow-xl border border-white/10">
          <div className="flex items-center gap-2 mb-4">
            <Sparkles className="text-brand-orange w-6 h-6" />
            <h2 className="text-xl font-bold">Mentor's Final Note</h2>
          </div>
          <p className="text-brand-silver text-sm leading-relaxed italic">
            "{session.aiFeedbackSummary}"
          </p>
        </section>
      </main>
    </div>
  );
}
