import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Flame, 
  Trophy, 
  MessageSquare, 
  BarChart3, 
  Settings as SettingsIcon,
  CheckCircle2,
  Clock,
  ArrowRight,
  LayoutDashboard
} from 'lucide-react';
import { 
  Radar, 
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  ResponsiveContainer 
} from 'recharts';
import { collection, query, onSnapshot, orderBy, limit } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { useAuth } from '../App';
import { Mission, UserSkillScore, SKILLS } from '../types';
import { cn } from '../lib/utils';
import { useNavigate } from 'react-router-dom';

export default function Dashboard() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [missions, setMissions] = useState<Mission[]>([]);
  const [scores, setScores] = useState<any[]>([]);

  useEffect(() => {
    if (!user) return;

    // Fetch Missions
    const missionsRef = collection(db, `users/${user.uid}/missions`);
    const qMissions = query(missionsRef, orderBy('assignedAt', 'desc'), limit(3));
    const unsubscribeMissions = onSnapshot(qMissions, (snap) => {
      const missionData = snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Mission));
      // Fallback missions if none exist
      if (missionData.length === 0) {
        setMissions([
          { id: '1', title: 'Professional Introduction', description: 'Practice your 30s elevator pitch.', estimatedMinutes: 5, category: 'Communication', xp: 50, status: 'pending' },
          { id: '2', title: 'Active Listening Drill', description: 'Listen to a scenario and summarize.', estimatedMinutes: 10, category: 'Delivery', xp: 75, status: 'pending' },
          { id: '3', title: 'Logic & Reasoning', description: 'Answer a complex situational question.', estimatedMinutes: 8, category: 'Cognitive', xp: 60, status: 'pending' }
        ]);
      } else {
        setMissions(missionData);
      }
    }, (err) => handleFirestoreError(err, OperationType.LIST, `users/${user.uid}/missions`));

    // Fetch Skill Scores for Radar Chart
    const scoresRef = collection(db, `users/${user.uid}/skill_scores`);
    const unsubscribeScores = onSnapshot(scoresRef, (snap) => {
      const scoreData = snap.docs.map(doc => doc.data() as UserSkillScore);
      
      // Group by skill category or just pick 5 core skills for the radar
      const radarData = [
        { subject: 'Communication', A: getAvgScore(scoreData, ['clarity', 'vocabulary', 'grammar']) },
        { subject: 'Confidence', A: getAvgScore(scoreData, ['confidence', 'fluency', 'pacing']) },
        { subject: 'Logic', A: getAvgScore(scoreData, ['logic', 'adaptability']) },
        { subject: 'Professionalism', A: getAvgScore(scoreData, ['tone', 'professionalism', 'formality']) },
        { subject: 'EQ', A: getAvgScore(scoreData, ['eq', 'empathy', 'active_listening']) }
      ];
      setScores(radarData);
    }, (err) => handleFirestoreError(err, OperationType.LIST, `users/${user.uid}/skill_scores`));

    return () => {
      unsubscribeMissions();
      unsubscribeScores();
    };
  }, [user]);

  const getAvgScore = (data: UserSkillScore[], skillIds: string[]) => {
    const relevant = data.filter(d => skillIds.includes(d.skillId));
    if (relevant.length === 0) return 3; // Default baseline
    return relevant.reduce((acc, curr) => acc + curr.score, 0) / relevant.length;
  };

  return (
    <div className="min-h-screen bg-brand-pearl pb-24">
      {/* Header */}
      <header className="bg-brand-charcoal text-white pt-12 pb-20 px-6 rounded-b-[3rem] shadow-xl">
        <div className="max-w-4xl mx-auto flex justify-between items-center">
          <div className="space-y-1">
            <p className="text-brand-orange text-xs font-bold uppercase tracking-widest">Welcome Back</p>
            <h1 className="text-2xl font-bold">{profile?.fullName}</h1>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-2xl border border-white/10">
              <Flame className="text-brand-orange w-5 h-5 fill-brand-orange" />
              <span className="font-bold">{profile?.streakCount || 0}</span>
            </div>
            <div className="w-12 h-12 bg-brand-orange rounded-2xl flex items-center justify-center shadow-lg shadow-brand-orange/20">
              <Trophy className="text-white w-6 h-6" />
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-6 -mt-12 space-y-8">
        {/* Skill Heatmap Card */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-[2.5rem] p-8 shadow-xl border border-brand-silver"
        >
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-bold text-brand-charcoal">Skill Radar</h2>
            <button 
              onClick={() => navigate('/analytics')}
              className="text-brand-orange text-sm font-bold flex items-center gap-1 hover:underline"
            >
              Full Report <ArrowRight className="w-4 h-4" />
            </button>
          </div>
          
          <div className="h-64 w-full radar-chart-container">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart cx="50%" cy="50%" outerRadius="80%" data={scores}>
                <PolarGrid stroke="#E2E8F0" />
                <PolarAngleAxis dataKey="subject" tick={{ fill: '#1A202C', fontSize: 12, fontWeight: 600 }} />
                <Radar
                  name="Skills"
                  dataKey="A"
                  stroke="#FF4F00"
                  fill="#FF4F00"
                  fillOpacity={0.2}
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Daily Missions */}
        <section className="space-y-4">
          <div className="flex justify-between items-center px-2">
            <h2 className="text-xl font-bold text-brand-charcoal">Daily Missions</h2>
            <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">3 Tasks Left</span>
          </div>

          <div className="space-y-4">
            {missions.map((mission, idx) => (
              <motion.div
                key={mission.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.1 }}
                onClick={() => navigate('/mentor')}
                className="bg-white p-6 rounded-3xl border border-brand-silver shadow-sm hover:shadow-md transition-all cursor-pointer group"
              >
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 bg-brand-pearl rounded-2xl flex items-center justify-center group-hover:bg-orange-50 transition-colors">
                    <div className="w-10 h-10 bg-brand-orange text-white rounded-xl flex items-center justify-center shadow-md">
                      <MessageSquare className="w-5 h-5" />
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-start">
                      <h3 className="font-bold text-brand-charcoal group-hover:text-brand-orange transition-colors">{mission.title}</h3>
                      <span className="bg-brand-pearl text-[10px] font-black uppercase px-2 py-1 rounded-lg text-gray-500">
                        {mission.xp} XP
                      </span>
                    </div>
                    <p className="text-sm text-gray-500 line-clamp-1">{mission.description}</p>
                    <div className="flex items-center gap-3 mt-2">
                      <div className="flex items-center gap-1 text-[10px] font-bold text-gray-400 uppercase">
                        <Clock className="w-3 h-3" /> {mission.estimatedMinutes}m
                      </div>
                      <div className="flex items-center gap-1 text-[10px] font-bold text-brand-orange uppercase">
                        <CheckCircle2 className="w-3 h-3" /> {mission.category}
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </section>
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-brand-charcoal px-8 py-4 flex justify-between items-center rounded-t-[2rem] shadow-2xl z-50">
        <button onClick={() => navigate('/')} className="flex flex-col items-center gap-1 text-brand-orange">
          <LayoutDashboard className="w-6 h-6" />
          <span className="text-[10px] font-bold uppercase">Home</span>
        </button>
        <button onClick={() => navigate('/mentor')} className="flex flex-col items-center gap-1 text-brand-silver hover:text-brand-orange transition-colors">
          <MessageSquare className="w-6 h-6" />
          <span className="text-[10px] font-bold uppercase">Mentor</span>
        </button>
        <button onClick={() => navigate('/analytics')} className="flex flex-col items-center gap-1 text-brand-silver hover:text-brand-orange transition-colors">
          <BarChart3 className="w-6 h-6" />
          <span className="text-[10px] font-bold uppercase">Stats</span>
        </button>
        <button onClick={() => navigate('/settings')} className="flex flex-col items-center gap-1 text-brand-silver hover:text-brand-orange transition-colors">
          <SettingsIcon className="w-6 h-6" />
          <span className="text-[10px] font-bold uppercase">Settings</span>
        </button>
      </nav>
    </div>
  );
}
