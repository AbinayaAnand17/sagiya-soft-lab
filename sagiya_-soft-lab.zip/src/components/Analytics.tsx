import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ChevronLeft, 
  Download, 
  TrendingUp, 
  Award, 
  Target,
  Calendar,
  LayoutDashboard,
  MessageSquare,
  BarChart3,
  Settings as SettingsIcon,
  PlayCircle,
  Clock,
  Sparkles,
  AlertCircle,
  CheckCircle2,
  Lightbulb
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell
} from 'recharts';
import { collection, query, onSnapshot, orderBy, limit } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { useAuth } from '../App';
import { UserSkillScore, SKILLS, PracticeSession } from '../types';
import { cn } from '../lib/utils';

export default function Analytics() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [timeSeriesData, setTimeSeriesData] = useState<any[]>([]);
  const [skillBreakdown, setSkillBreakdown] = useState<any[]>([]);
  const [recentSessions, setRecentSessions] = useState<PracticeSession[]>([]);
  const [activeTab, setActiveTab] = useState<'performance' | 'growth'>('performance');

  useEffect(() => {
    if (!user) return;

    // Fetch Scores
    const scoresRef = collection(db, `users/${user.uid}/skill_scores`);
    const qScores = query(scoresRef, orderBy('recordedAt', 'asc'));
    
    const unsubscribeScores = onSnapshot(qScores, (snap) => {
      const data = snap.docs.map(doc => doc.data() as UserSkillScore);
      
      const dailyAvgs: { [key: string]: { total: number, count: number } } = {};
      data.forEach(d => {
        const date = new Date(d.recordedAt.toString()).toLocaleDateString();
        if (!dailyAvgs[date]) dailyAvgs[date] = { total: 0, count: 0 };
        dailyAvgs[date].total += d.score;
        dailyAvgs[date].count += 1;
      });
      
      const lineData = Object.entries(dailyAvgs).map(([date, val]) => ({
        date,
        score: parseFloat((val.total / val.count).toFixed(1))
      }));
      setTimeSeriesData(lineData);

      const skillTotals: { [key: string]: { total: number, count: number } } = {};
      data.forEach(d => {
        if (!skillTotals[d.skillId]) skillTotals[d.skillId] = { total: 0, count: 0 };
        skillTotals[d.skillId].total += d.score;
        skillTotals[d.skillId].count += 1;
      });

      const barData = SKILLS.map(s => ({
        name: s.name,
        score: skillTotals[s.id] ? parseFloat((skillTotals[s.id].total / skillTotals[s.id].count).toFixed(1)) : 0
      })).filter(s => s.score > 0);
      setSkillBreakdown(barData);
    }, (err) => handleFirestoreError(err, OperationType.LIST, `users/${user.uid}/skill_scores`));

    // Fetch Recent Sessions (More for analysis)
    const sessionsRef = collection(db, `users/${user.uid}/sessions`);
    const qSessions = query(sessionsRef, orderBy('createdAt', 'desc'), limit(10));
    const unsubscribeSessions = onSnapshot(qSessions, (snap) => {
      setRecentSessions(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as PracticeSession)));
    }, (err) => handleFirestoreError(err, OperationType.LIST, `users/${user.uid}/sessions`));

    return () => {
      unsubscribeScores();
      unsubscribeSessions();
    };
  }, [user]);

  // Analyze feedback patterns
  const growthInsights = useMemo(() => {
    const feedbackCounts: { [key: string]: number } = {};
    const allTips: string[] = [];
    
    recentSessions.forEach(session => {
      session.messages.forEach(msg => {
        if (msg.feedback) {
          const tip = msg.feedback.toLowerCase();
          feedbackCounts[tip] = (feedbackCounts[tip] || 0) + 1;
          allTips.push(msg.feedback);
        }
      });
    });

    const recurring = Object.entries(feedbackCounts)
      .filter(([_, count]) => count > 1)
      .sort((a, b) => b[1] - a[1])
      .map(([tip]) => tip);

    return {
      recurring,
      recentTips: allTips.slice(0, 5),
      hasData: allTips.length > 0
    };
  }, [recentSessions]);

  return (
    <div className="min-h-screen bg-brand-pearl pb-24">
      <header className="bg-brand-charcoal text-white p-6 flex flex-col gap-6 sticky top-0 z-10 shadow-md">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button onClick={() => navigate('/')} className="p-2 hover:bg-white/10 rounded-xl transition-colors">
              <ChevronLeft className="w-6 h-6" />
            </button>
            <h1 className="font-bold text-lg">Skill Intelligence</h1>
          </div>
          <button className="p-2 bg-brand-orange rounded-xl hover:bg-opacity-90 transition-all">
            <Download className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex bg-white/5 p-1 rounded-2xl border border-white/10">
          <button 
            onClick={() => setActiveTab('performance')}
            className={cn(
              "flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all",
              activeTab === 'performance' ? "bg-brand-orange text-white shadow-lg" : "text-brand-silver hover:text-white"
            )}
          >
            Performance
          </button>
          <button 
            onClick={() => setActiveTab('growth')}
            className={cn(
              "flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all",
              activeTab === 'growth' ? "bg-brand-orange text-white shadow-lg" : "text-brand-silver hover:text-white"
            )}
          >
            Growth Insights
          </button>
        </div>
      </header>

      <main className="p-6 space-y-8 max-w-4xl mx-auto">
        <AnimatePresence mode="wait">
          {activeTab === 'performance' ? (
            <motion.div
              key="performance"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-8"
            >
              {/* Growth Curve */}
              <section className="bg-white p-8 rounded-[2.5rem] shadow-xl border border-brand-silver">
                <div className="flex items-center gap-2 mb-6">
                  <TrendingUp className="text-brand-orange w-5 h-5" />
                  <h2 className="text-xl font-bold text-brand-charcoal">Growth Curve</h2>
                </div>
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={timeSeriesData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                      <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#94A3B8' }} axisLine={false} tickLine={false} />
                      <YAxis domain={[0, 10]} tick={{ fontSize: 10, fill: '#94A3B8' }} axisLine={false} tickLine={false} />
                      <Tooltip 
                        contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }}
                        itemStyle={{ color: '#FF4F00', fontWeight: 'bold' }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="score" 
                        stroke="#FF4F00" 
                        strokeWidth={4} 
                        dot={{ r: 6, fill: '#FF4F00', strokeWidth: 0 }}
                        activeDot={{ r: 8, strokeWidth: 0 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </section>

              {/* Recent Sessions List */}
              <section className="space-y-4">
                <div className="flex items-center gap-2 px-2">
                  <PlayCircle className="text-brand-orange w-5 h-5" />
                  <h2 className="text-xl font-bold text-brand-charcoal">Recent Sessions</h2>
                </div>
                <div className="space-y-3">
                  {recentSessions.slice(0, 5).map((session) => (
                    <motion.div
                      key={session.id}
                      whileHover={{ scale: 1.01 }}
                      onClick={() => navigate(`/replay/${session.id}`)}
                      className="bg-white p-5 rounded-3xl border border-brand-silver shadow-sm flex items-center justify-between cursor-pointer group"
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-brand-pearl rounded-2xl flex items-center justify-center group-hover:bg-orange-50 transition-colors">
                          <MessageSquare className="w-6 h-6 text-brand-orange" />
                        </div>
                        <div>
                          <h3 className="font-bold text-brand-charcoal group-hover:text-brand-orange transition-colors">
                            {session.sessionType} Session
                          </h3>
                          <div className="flex items-center gap-3 text-[10px] font-bold text-gray-400 uppercase">
                            <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {new Date(session.createdAt).toLocaleDateString()}</span>
                            <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {Math.floor(session.durationSeconds / 60)}m</span>
                          </div>
                        </div>
                      </div>
                      <div className="bg-brand-orange/10 p-2 rounded-xl text-brand-orange group-hover:bg-brand-orange group-hover:text-white transition-all">
                        <PlayCircle className="w-5 h-5" />
                      </div>
                    </motion.div>
                  ))}
                </div>
              </section>

              {/* Skill Breakdown */}
              <section className="bg-white p-8 rounded-[2.5rem] shadow-xl border border-brand-silver">
                <div className="flex items-center gap-2 mb-6">
                  <Award className="text-brand-orange w-5 h-5" />
                  <h2 className="text-xl font-bold text-brand-charcoal">Skill Breakdown</h2>
                </div>
                <div className="h-80 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={skillBreakdown} layout="vertical">
                      <XAxis type="number" domain={[0, 10]} hide />
                      <YAxis dataKey="name" type="category" tick={{ fontSize: 10, fontWeight: 600, fill: '#1A202C' }} width={100} axisLine={false} tickLine={false} />
                      <Tooltip cursor={{ fill: 'transparent' }} />
                      <Bar dataKey="score" radius={[0, 8, 8, 0]} barSize={20}>
                        {skillBreakdown.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.score > 7.5 ? '#10B981' : '#FF4F00'} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </section>
            </motion.div>
          ) : (
            <motion.div
              key="growth"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              {/* Recurring Bottlenecks */}
              <section className="bg-white p-8 rounded-[2.5rem] shadow-xl border border-brand-silver">
                <div className="flex items-center gap-2 mb-6">
                  <AlertCircle className="text-brand-orange w-6 h-6" />
                  <h2 className="text-xl font-bold text-brand-charcoal">Recurring Bottlenecks</h2>
                </div>
                
                {growthInsights.recurring.length > 0 ? (
                  <div className="space-y-4">
                    {growthInsights.recurring.map((tip, idx) => (
                      <div key={idx} className="flex items-start gap-4 p-4 bg-orange-50 rounded-2xl border border-brand-orange/10">
                        <div className="w-8 h-8 bg-brand-orange text-white rounded-full flex items-center justify-center font-black text-xs shrink-0">
                          !
                        </div>
                        <div>
                          <p className="text-sm font-bold text-brand-charcoal capitalize">{tip}</p>
                          <p className="text-[10px] font-medium text-brand-charcoal/60 uppercase tracking-wider mt-1">
                            Identified in multiple sessions
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12 bg-brand-pearl rounded-3xl border border-dashed border-brand-silver">
                    <CheckCircle2 className="w-12 h-12 text-brand-success mx-auto mb-4 opacity-20" />
                    <p className="text-sm font-medium text-gray-400">No recurring bottlenecks detected yet.<br/>Keep practicing to reveal patterns!</p>
                  </div>
                )}
              </section>

              {/* Actionable Advice */}
              <section className="bg-brand-charcoal text-white p-8 rounded-[2.5rem] shadow-xl border border-white/10 relative overflow-hidden">
                <div className="absolute top-0 right-0 p-8 opacity-10">
                  <Lightbulb className="w-32 h-32 text-brand-orange" />
                </div>
                <div className="relative z-10">
                  <div className="flex items-center gap-2 mb-6">
                    <Sparkles className="text-brand-orange w-6 h-6" />
                    <h2 className="text-xl font-bold">Growth Strategy</h2>
                  </div>
                  
                  <div className="space-y-6">
                    <div className="bg-white/5 p-6 rounded-2xl border border-white/10">
                      <h3 className="text-brand-orange font-bold text-sm mb-2 uppercase tracking-widest">Focus Area</h3>
                      <p className="text-brand-silver text-sm leading-relaxed">
                        Based on your recent sessions, focusing on <strong>{growthInsights.recurring[0] || 'Fluency'}</strong> will yield the highest growth. Try to slow down your speech by 10% to reduce filler words.
                      </p>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-white/5 p-4 rounded-2xl border border-white/10">
                        <p className="text-[10px] font-bold text-brand-silver uppercase mb-1">Next Milestone</p>
                        <p className="text-lg font-black text-white">Level 5</p>
                      </div>
                      <div className="bg-white/5 p-4 rounded-2xl border border-white/10">
                        <p className="text-[10px] font-bold text-brand-silver uppercase mb-1">XP to Goal</p>
                        <p className="text-lg font-black text-white">450 XP</p>
                      </div>
                    </div>
                  </div>
                </div>
              </section>

              {/* Feedback Archive */}
              <section className="space-y-4">
                <div className="flex items-center gap-2 px-2">
                  <MessageSquare className="text-brand-orange w-5 h-5" />
                  <h2 className="text-xl font-bold text-brand-charcoal">Feedback Archive</h2>
                </div>
                <div className="space-y-3">
                  {growthInsights.recentTips.map((tip, idx) => (
                    <motion.div
                      key={idx}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.1 }}
                      className="bg-white p-5 rounded-3xl border border-brand-silver shadow-sm flex items-center gap-4"
                    >
                      <div className="w-10 h-10 bg-brand-pearl rounded-xl flex items-center justify-center shrink-0">
                        <Lightbulb className="w-5 h-5 text-brand-orange" />
                      </div>
                      <p className="text-sm font-medium text-brand-charcoal">{tip}</p>
                    </motion.div>
                  ))}
                  {!growthInsights.hasData && (
                    <div className="text-center py-8 text-gray-400 font-medium italic">
                      No feedback recorded yet.
                    </div>
                  )}
                </div>
              </section>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-brand-charcoal text-white p-6 rounded-3xl shadow-lg">
            <Target className="text-brand-orange w-6 h-6 mb-2" />
            <p className="text-[10px] font-bold uppercase tracking-widest text-brand-silver">Total XP</p>
            <h3 className="text-2xl font-black">{profile?.totalXP || 0}</h3>
          </div>
          <div className="bg-white p-6 rounded-3xl shadow-lg border border-brand-silver">
            <Calendar className="text-brand-orange w-6 h-6 mb-2" />
            <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Level</p>
            <h3 className="text-2xl font-black text-brand-charcoal">{profile?.level || 1}</h3>
          </div>
        </div>
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-brand-charcoal px-8 py-4 flex justify-between items-center rounded-t-[2rem] shadow-2xl z-50">
        <button onClick={() => navigate('/')} className="flex flex-col items-center gap-1 text-brand-silver hover:text-brand-orange transition-colors">
          <LayoutDashboard className="w-6 h-6" />
          <span className="text-[10px] font-bold uppercase">Home</span>
        </button>
        <button onClick={() => navigate('/mentor')} className="flex flex-col items-center gap-1 text-brand-silver hover:text-brand-orange transition-colors">
          <MessageSquare className="w-6 h-6" />
          <span className="text-[10px] font-bold uppercase">Mentor</span>
        </button>
        <button onClick={() => navigate('/analytics')} className="flex flex-col items-center gap-1 text-brand-orange">
          <BarChart3 className="w-6 h-6" />
          <span className="text-[10px] font-bold uppercase">Stats</span>
        </button>
        <button onClick={() => navigate('/settings')} className="flex flex-col items-center gap-1 text-brand-silver hover:text-brand-orange transition-colors">
          <SettingsIcon className="w-6 h-6" />
          <span className="text-[10px] font-bold uppercase">Settings</span>
        </button>
      </nav>
    </div>
  );
}
