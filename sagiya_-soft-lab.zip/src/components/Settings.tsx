import React from 'react';
import { motion } from 'motion/react';
import { 
  ChevronLeft, 
  User, 
  Shield, 
  Bell, 
  Globe, 
  LogOut, 
  Trash2,
  ChevronRight,
  LayoutDashboard,
  MessageSquare,
  BarChart3,
  Settings as SettingsIcon
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { auth } from '../firebase';
import { useAuth } from '../App';
import { cn } from '../lib/utils';

export default function Settings() {
  const { profile } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await auth.signOut();
    navigate('/login');
  };

  const SettingItem = ({ icon: Icon, label, value, onClick, danger }: any) => (
    <button 
      onClick={onClick}
      className="w-full bg-white p-6 rounded-3xl border border-brand-silver flex items-center justify-between group hover:border-brand-orange/50 transition-all"
    >
      <div className="flex items-center gap-4">
        <div className={cn(
          "w-12 h-12 rounded-2xl flex items-center justify-center transition-colors",
          danger ? "bg-red-50 text-red-500" : "bg-brand-pearl text-brand-charcoal group-hover:bg-orange-50 group-hover:text-brand-orange"
        )}>
          <Icon className="w-6 h-6" />
        </div>
        <div className="text-left">
          <p className="font-bold text-brand-charcoal">{label}</p>
          {value && <p className="text-xs text-gray-400 font-medium">{value}</p>}
        </div>
      </div>
      <ChevronRight className={cn("w-5 h-5", danger ? "text-red-300" : "text-brand-silver group-hover:text-brand-orange")} />
    </button>
  );

  return (
    <div className="min-h-screen bg-brand-pearl pb-24">
      <header className="bg-brand-charcoal text-white p-6 flex items-center gap-4 sticky top-0 z-10 shadow-md">
        <button onClick={() => navigate('/')} className="p-2 hover:bg-white/10 rounded-xl transition-colors">
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h1 className="font-bold text-lg">Settings</h1>
      </header>

      <main className="p-6 space-y-8 max-w-4xl mx-auto">
        {/* Profile Summary */}
        <section className="bg-brand-charcoal text-white p-8 rounded-[2.5rem] shadow-xl flex items-center gap-6 border border-white/10">
          <div className="w-20 h-20 bg-brand-orange rounded-3xl flex items-center justify-center text-3xl font-black shadow-lg shadow-brand-orange/20">
            {profile?.fullName?.[0] || 'P'}
          </div>
          <div>
            <h2 className="text-xl font-bold">{profile?.fullName}</h2>
            <p className="text-brand-silver text-sm">{profile?.phoneNumber}</p>
            <div className="mt-2 inline-flex items-center gap-1.5 bg-white/10 px-3 py-1 rounded-full border border-white/10">
              <div className="w-1.5 h-1.5 bg-brand-orange rounded-full"></div>
              <span className="text-[10px] font-bold uppercase tracking-widest">Level {profile?.level || 1} Professional</span>
            </div>
          </div>
        </section>

        {/* Setting Groups */}
        <div className="space-y-4">
          <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest px-2">Account & Privacy</h3>
          <SettingItem icon={User} label="Profile Information" value="Name, Goals, Career Track" />
          <SettingItem icon={Shield} label="DPDP Consent Center" value="Manage AI data permissions" />
          <SettingItem icon={Globe} label="Language" value="English (Default)" />
        </div>

        <div className="space-y-4">
          <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest px-2">Preferences</h3>
          <SettingItem icon={Bell} label="Notifications" value="Daily missions, Streak alerts" />
        </div>

        <div className="space-y-4">
          <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest px-2">Danger Zone</h3>
          <SettingItem icon={LogOut} label="Logout" onClick={handleLogout} />
          <SettingItem icon={Trash2} label="Delete AI Data" danger />
        </div>
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-brand-charcoal px-8 py-4 flex justify-between items-center rounded-t-[2rem] shadow-2xl z-50">
        <button onClick={() => navigate('/')} className="flex flex-col items-center gap-1 text-brand-silver hover:text-brand-orange transition-colors">
          <LayoutDashboard className="w-6 h-6" />
          <span className="text-[10px] font-bold uppercase">Home</span>
        </button>
        <button onClick={() => navigate('/mentor')} className="flex flex-col items-center gap-1 text-brand-silver hover:text-brand-orange transition-colors">
          <MessageSquare className="w-6 h-6" />
          <span className="text-[10px] font-bold uppercase">Mentor</span>
        </button>
        <button onClick={() => navigate('/analytics')} className="flex flex-col items-center gap-1 text-brand-silver hover:text-brand-orange transition-colors">
          <BarChart3 className="w-6 h-6" />
          <span className="text-[10px] font-bold uppercase">Stats</span>
        </button>
        <button onClick={() => navigate('/settings')} className="flex flex-col items-center gap-1 text-brand-orange">
          <SettingsIcon className="w-6 h-6" />
          <span className="text-[10px] font-bold uppercase">Settings</span>
        </button>
      </nav>
    </div>
  );
}
