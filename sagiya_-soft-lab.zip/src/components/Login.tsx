import React, { useState } from 'react';
import { signInWithPopup, GoogleAuthProvider, signInWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../firebase';
import { motion } from 'motion/react';
import { LogIn, ShieldCheck, Mail, Lock } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { cn } from '../lib/utils';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [consent, setConsent] = useState(false);
  const navigate = useNavigate();

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!consent) return;
    
    setLoading(true);
    setError(null);
    try {
      await signInWithEmailAndPassword(auth, email, password);
      navigate('/');
    } catch (err: any) {
      console.error(err);
      setError("Invalid email or password");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    if (!consent) return;
    
    setLoading(true);
    setError(null);
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
      navigate('/');
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to sign in");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-brand-pearl flex flex-col items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full"
      >
        <div className="bg-brand-charcoal rounded-3xl p-8 shadow-2xl border border-brand-orange/20">
          <div className="text-center mb-10">
            <motion.div
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.5 }}
              className="inline-block mb-4"
            >
              <h1 className="text-4xl font-black tracking-tighter text-white">
                SAGIYA<span className="text-brand-orange">:</span> SOFT LAB
              </h1>
            </motion.div>
            <p className="text-brand-silver text-sm font-medium tracking-wide uppercase">
              AI-Driven Soft Skill Intelligence
            </p>
          </div>

          <form onSubmit={handleEmailLogin} className="space-y-4">
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-brand-silver uppercase px-1">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-brand-silver" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@company.com"
                  className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-12 pr-4 text-white text-sm focus:outline-none focus:border-brand-orange transition-colors"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-brand-silver uppercase px-1">Password</label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-brand-silver" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-12 pr-4 text-white text-sm focus:outline-none focus:border-brand-orange transition-colors"
                />
              </div>
            </div>

            <div className="flex items-start gap-3 py-2">
              <div className="pt-1">
                <input 
                  type="checkbox" 
                  id="consent"
                  checked={consent}
                  onChange={(e) => setConsent(e.target.checked)}
                  className="w-5 h-5 rounded border-brand-silver text-brand-orange focus:ring-brand-orange accent-brand-orange"
                />
              </div>
              <label htmlFor="consent" className="text-xs text-brand-silver leading-relaxed">
                I agree to the <span className="text-brand-orange underline cursor-pointer">DPDP 2023 Compliance</span> terms and consent to AI processing of my voice and text data.
              </label>
            </div>

            <button
              type="submit"
              disabled={!consent || loading}
              className={cn(
                "w-full py-4 rounded-xl font-bold flex items-center justify-center gap-3 transition-all",
                consent && !loading 
                  ? 'bg-brand-orange text-white hover:scale-[1.02] active:scale-[0.98] shadow-lg shadow-brand-orange/20' 
                  : 'bg-brand-silver/20 text-brand-silver cursor-not-allowed'
              )}
            >
              {loading ? (
                <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <>
                  <LogIn className="w-5 h-5" />
                  Login to Platform
                </>
              )}
            </button>
          </form>

          <div className="relative my-8">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-white/10"></div>
            </div>
            <div className="relative flex justify-center text-[10px] uppercase font-bold">
              <span className="bg-brand-charcoal px-4 text-brand-silver">Or continue with</span>
            </div>
          </div>

          <button
            onClick={handleGoogleLogin}
            disabled={!consent || loading}
            className="w-full py-3 rounded-xl border border-white/10 text-white text-sm font-bold flex items-center justify-center gap-3 hover:bg-white/5 transition-all"
          >
            <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" className="w-5 h-5" alt="Google" />
            Google
          </button>

          <p className="mt-8 text-center text-xs text-brand-silver">
            Don't have an account?{' '}
            <Link to="/register" className="text-brand-orange font-bold hover:underline">
              Register here
            </Link>
          </p>

          {error && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="mt-4 bg-red-500/10 border border-red-500/20 text-red-400 p-3 rounded-lg text-xs text-center"
            >
              {error}
            </motion.div>
          )}
        </div>

        <div className="mt-12 text-center">
          <div className="flex items-center justify-center gap-2 text-brand-charcoal/40 text-xs font-medium italic">
            <ShieldCheck className="w-4 h-4" />
            "From Student to Professional — Guided by AI"
          </div>
        </div>
      </motion.div>
    </div>
  );
}
